import React, { Component } from "react";

class ImagenTitulo extends Component {
  render () {
    return (
      <div class="apartamento">
      <img src="https://www.nobili-interior-design.ro/images/design-interior-case-moderne-2016-constanta.jpg" align="center"/>
      <div class="centrado"> Mensualidad Conjunto Residencial</div>
      </div>
    );
  }
  
}
export default ImagenTitulo;