import React from "react";


function Encabezado (){
  return(
    <div>
    <div class = "tabla2"> 
    <table class= "table2" border="1" align="center">
    <tr bgcolor="">
      <th> Inicio</th>
       <th> Mensualidad</th>
      <th> Contactanos</th>
    </tr>
    </table> 

  </div>


  <div class="encabezado">
  
    
  <img src="https://www.creativefabrica.com/wp-content/uploads/2019/02/Monogram-CR-Logo-by-Greenlines-Studios-580x387.jpg"align = "center"/>

    <input type="text" placeholder="&#128269; Search"name="Buscar" value="Buscar"/>
  </div>

  <div class= "Casita - home">
    <img src="https://static.vecteezy.com/system/resources/previews/000/423/572/non_2x/house-icon-vector-illustration.jpg" align= "center"/>

 </div>

 

 </div>
  
  );
}
export default Encabezado;